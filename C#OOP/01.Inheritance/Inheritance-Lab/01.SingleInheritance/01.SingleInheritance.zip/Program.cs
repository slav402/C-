﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Dog bobi = new Dog();

            bobi.Eat();
            bobi.Bark();
        }
    }
}
