﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Models.Interfaces
{
    internal interface Ibrowsable
    {
        string Browse(string url);
    }
}
