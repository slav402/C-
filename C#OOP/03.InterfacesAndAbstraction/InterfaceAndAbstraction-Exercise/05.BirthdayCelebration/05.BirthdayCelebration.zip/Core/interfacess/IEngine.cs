﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorederControl.Core.interfacess
{
    internal interface IEngine
    {
        void Run();
    }
}
