﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorederControl.Models.Interfacess
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
