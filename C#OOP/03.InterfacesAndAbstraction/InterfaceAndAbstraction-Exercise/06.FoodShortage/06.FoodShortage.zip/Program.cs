﻿using FoodShortage.Core;
using System;

namespace FoodShortage
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
