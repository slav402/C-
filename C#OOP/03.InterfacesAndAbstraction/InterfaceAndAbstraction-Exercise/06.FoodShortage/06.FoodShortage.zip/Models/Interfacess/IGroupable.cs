﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Models.Interfacess
{
    public interface IGroupable
    {
        string Group { get; }
    }
}
