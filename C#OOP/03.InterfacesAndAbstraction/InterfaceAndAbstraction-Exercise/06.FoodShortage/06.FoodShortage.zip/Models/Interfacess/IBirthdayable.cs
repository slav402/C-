﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Models.Interfacess
{
    public interface IBirthdayable
    {
        string Birthday { get; }
    }
}
