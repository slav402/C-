﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Core.Interfacess
{
    internal interface IEngine
    {
        void Run();
    }
}
