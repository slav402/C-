﻿namespace Telephony
{
    public interface IBrowsable
    {
        string Site { get; set; }

        void Browsing();
    }
}
