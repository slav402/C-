﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Models.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
