﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            MuseElf mani = new MuseElf("Bibi", 69);

            Console.WriteLine(mani);
        }
    }
}